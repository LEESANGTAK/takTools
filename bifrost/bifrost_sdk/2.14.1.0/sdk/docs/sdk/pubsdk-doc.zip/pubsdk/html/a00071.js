var a00071 =
[
    [ "Amino::TypeId", "a00370.html", "a00370" ],
    [ "getTypeId", "a00071.html#a17944f9b0e90db89830b73ce267b12bc", null ]
];