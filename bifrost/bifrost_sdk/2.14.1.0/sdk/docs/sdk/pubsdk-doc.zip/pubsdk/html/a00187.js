var a00187 =
[
    [ "Bifrost::Geometry::findPrototype", "a00187.html#ga06c9fb8b8c500aefdb7185a3ee4ea2e5", null ],
    [ "Bifrost::Geometry::getGeometryTypes", "a00187.html#gaa9525f4e3b031799cb194d8b66e255dc", null ],
    [ "Bifrost::Geometry::resolveType", "a00187.html#ga10f991f8398166e2fc11f6968a4d325e", null ]
];