var a00134 =
[
    [ "Bifrost::Object::Property", "a00998.html", "a00998" ],
    [ "BIFROST_IGNORE_NAMESPACE", "a00134.html#af19f36f76ac97bc96f7aadbeec6a97b2", null ],
    [ "createObject", "a00134.html#gae194fcdfbe14fd65d047b005159ce0d0", null ],
    [ "createObject", "a00134.html#gad76753d88490267d820f5aa7530d07cb", null ]
];