var a00113 =
[
    [ "BIFMETADOC", "a00113.html#a123f5c0aaab449c3f7d24f9771e059be", null ],
    [ "BIFMETAICN", "a00113.html#a0367c320a3dd042d316bd7ae5c461c9f", null ],
    [ "BIFROST_GEOMETRY_DECL", "a00113.html#a79fa8b2e3b87072170b261c1398f437f", null ],
    [ "BIFROST_GEOMETRY_EXPORT", "a00113.html#a6a30c7ae0dc81e1fb02a6a0c605cb8ff", null ],
    [ "BIFROST_GEOMETRY_IMPORT", "a00113.html#a15613032a5f6a7f28291fa00d2fcee70", null ]
];