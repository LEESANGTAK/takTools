var a00338 =
[
    [ "StopToken", "a00338.html#ac9fb4c6dbf7d03dcb470e46001456f23", null ],
    [ "StopToken", "a00338.html#a293ea4b8f70adbd21cee2b1ea3b9c4d1", null ],
    [ "StopToken", "a00338.html#ab5aace2d36c7feddbd26cf19f229b839", null ],
    [ "~StopToken", "a00338.html#a8e6f9a4caaee37f1450463d4dd4a4bfe", null ],
    [ "operator=", "a00338.html#aee9b16b3eab730ad9064c7fbfc985b03", null ],
    [ "operator=", "a00338.html#a5b0a5fa73b14209cf8864ba19097cfb4", null ],
    [ "stopPossible", "a00338.html#a262e48448a0876b0ba7ddb6109d2de81", null ],
    [ "stopRequested", "a00338.html#a1f9c84b9a9d096bcfb1e7f7bedc980ca", null ],
    [ "operator!=", "a00338.html#a74163fb9eb835e0fc0169b182c9e437a", null ],
    [ "operator==", "a00338.html#ac6dd65df1ae3d00915e90e71f831aaf8", null ]
];