var a00270 =
[
    [ "NamingUtilities", "a00270.html#a0fe0ddc3ecd5713ddd9e8771694f3c1d", null ],
    [ "NamingUtilities", "a00270.html#a33701d96e09bb8a0fcbf597ba45e0d44", null ],
    [ "getLegalName", "a00270.html#a669963789865ff54207725b9a6247a68", null ],
    [ "isLegalName", "a00270.html#abbb03b4009723022afb854a46553f622", null ],
    [ "legalize", "a00270.html#ad1b31d856e7e00647f943614c13d17ab", null ],
    [ "operator=", "a00270.html#af7242ac8aad3144aae9b1402cbca4acd", null ]
];