var a00490 =
[
    [ "w", "a00490.html#abf7f40d3bb15789a33822d8b5f1bf5a5", null ],
    [ "x", "a00490.html#a6e915ac9f645269305c7f5f56077fb3a", null ],
    [ "y", "a00490.html#afe561a14791ae8dcc85b7e21ca07f41b", null ],
    [ "z", "a00490.html#a7f4b4d2fb471356c5ad47b7a35c2a940", null ]
];