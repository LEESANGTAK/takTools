var a00530 =
[
    [ "x", "a00530.html#a7dafbe1922971a418b5fcf5d402238a8", null ],
    [ "y", "a00530.html#ac813653ef264026359c4f7cb4746b6ad", null ]
];