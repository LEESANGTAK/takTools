var a00482 =
[
    [ "x", "a00482.html#ae510552cb5200a70642dc499fd2d18e3", null ],
    [ "y", "a00482.html#a60b02a3389fbebe9909ef39c0114c3b1", null ]
];