var a00194 =
[
    [ "Bifrost::createObject", "a00194.html#gae194fcdfbe14fd65d047b005159ce0d0", null ],
    [ "Bifrost::createObject", "a00194.html#gad76753d88490267d820f5aa7530d07cb", null ]
];