var a00234 =
[
    [ "ConversionData", "a00238.html", "a00238" ],
    [ "ConversionMode", "a00234.html#af41c4462810ad83a917f54bee35cdffa", [
      [ "kNone", "a00234.html#af41c4462810ad83a917f54bee35cdffaa35c3ace1970663a16e5c65baa5941b13", null ],
      [ "kConversionToShape", "a00234.html#af41c4462810ad83a917f54bee35cdffaa24574226602333fb4b610735aac93b9c", null ],
      [ "kConversionToBoard", "a00234.html#af41c4462810ad83a917f54bee35cdffaac297b305990c7b2292e85ebca7fdaeea", null ]
    ] ],
    [ "PortCreationData", "a00234.html#a719a58b96de2e7f9639c27a101e8960c", null ],
    [ "~PortCreationData", "a00234.html#a912a14dc4c8ea4b1593da813ecb32e51", null ],
    [ "m_conversionData", "a00234.html#a963c91d45ca7ba6c5fddd9c38e51779a", null ],
    [ "m_modifier", "a00234.html#a7b751de1c76fa0ead0d92b31426c2e20", null ]
];