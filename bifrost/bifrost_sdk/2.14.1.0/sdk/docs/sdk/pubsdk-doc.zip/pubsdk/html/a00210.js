var a00210 =
[
    [ "FileOperationMultiResults", "a00918.html", "a00918" ],
    [ "FileOperationSingleResult", "a00914.html", "a00914" ],
    [ "FileOperationKind", "a00210.html#a85e5516028a2108f49b987e3e39c7e1e", [
      [ "ReadFile", "a00210.html#a85e5516028a2108f49b987e3e39c7e1ea9793e97d7800c4d457a5ddacf2871fba", null ],
      [ "WriteFile", "a00210.html#a85e5516028a2108f49b987e3e39c7e1ea0305fc2edef33839fdf17bba2f9d98fe", null ]
    ] ]
];