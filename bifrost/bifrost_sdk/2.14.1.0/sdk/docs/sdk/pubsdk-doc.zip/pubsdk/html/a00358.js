var a00358 =
[
    [ "argument_type", "a00358.html#a7cf32e4b629e383256aeb0e141deaae0", null ],
    [ "result_type", "a00358.html#a62923b433025ab94c8701cee3887c476", null ],
    [ "operator()", "a00358.html#addcfa12519fbf7af303642eb56e49588", null ]
];