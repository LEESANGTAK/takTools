var a00089 =
[
    [ "Bifrost::Math::FCurve", "a00374.html", "a00374" ],
    [ "BIFROST_IGNORE_NAMESPACE", "a00089.html#af19f36f76ac97bc96f7aadbeec6a97b2", null ],
    [ "AMINO_DECLARE_DEFAULT_CLASS", "a00089.html#a99a7cffccd91d998c5bdef220de2311e", null ]
];