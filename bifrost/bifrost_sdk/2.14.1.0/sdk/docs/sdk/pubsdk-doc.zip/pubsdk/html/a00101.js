var a00101 =
[
    [ "Bifrost::File::Common::FileOperationSingleResult", "a00914.html", "a00914" ],
    [ "Bifrost::File::Common::FileOperationMultiResults", "a00918.html", "a00918" ],
    [ "Bifrost::File::Project::SceneInfo", "a00922.html", "a00922" ],
    [ "BIFROST_IGNORE_NAMESPACE", "a00101.html#af19f36f76ac97bc96f7aadbeec6a97b2", null ],
    [ "FileOperationKind", "a00101.html#a85e5516028a2108f49b987e3e39c7e1e", [
      [ "ReadFile", "a00101.html#a85e5516028a2108f49b987e3e39c7e1ea9793e97d7800c4d457a5ddacf2871fba", null ],
      [ "WriteFile", "a00101.html#a85e5516028a2108f49b987e3e39c7e1ea0305fc2edef33839fdf17bba2f9d98fe", null ]
    ] ]
];