var a00310 =
[
    [ "argument_type", "a00310.html#ac7c8dba5bc79243bfcb9c7f443c9e4d1", null ],
    [ "result_type", "a00310.html#a0a54945c6e6722e0cf6a1b26b513a3ad", null ],
    [ "operator()", "a00310.html#aaba427dec0a24a445bdfa6590fd8c8e8", null ]
];