var a00098 =
[
    [ "_bifrost_arch_", "a00098.html#ac54f2a7b70c46df4edc891cab4b8fb3b", null ],
    [ "_bifrost_major_", "a00098.html#a575528771b28adb1008710435761d290", null ],
    [ "_bifrost_minor_", "a00098.html#aa6b7a5789a4bfc7897b57126564f93c9", null ],
    [ "_bifrost_patch_", "a00098.html#ad9fcccae18ec4a6ae179532092385cf0", null ],
    [ "_bifrost_version_", "a00098.html#a47d77266e4ab2f8214340307700b1fac", null ],
    [ "getArchNumber", "a00098.html#a8aa3d78d6907703aac87707500c20cda", null ],
    [ "getAsNumber", "a00098.html#a773d77c39dc44d8d0e5a3cb731252cde", null ],
    [ "getAsString", "a00098.html#a2b149452afa26a1de79636ee45c06399", null ],
    [ "getMajorNumber", "a00098.html#a273fd738d5c9f2c0c1326e4f65c1addd", null ],
    [ "getMinorNumber", "a00098.html#a8d74d04b1d2197d66f9398189d5ed00b", null ],
    [ "getPatchNumber", "a00098.html#a8ebedce7df847596db1814832931de4c", null ]
];