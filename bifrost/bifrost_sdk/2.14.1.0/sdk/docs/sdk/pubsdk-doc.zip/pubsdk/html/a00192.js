var a00192 =
[
    [ "Bifrost::Geometry::getInstancesPrototype", "a00192.html#gafffa2d8f766586105c05ab0015dfbd8d", null ],
    [ "Bifrost::Geometry::populateInstances", "a00192.html#ga29ff9625e21471db74f3efccb53c3938", null ]
];