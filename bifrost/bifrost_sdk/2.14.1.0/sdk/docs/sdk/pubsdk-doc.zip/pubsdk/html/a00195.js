var a00195 =
[
    [ "EXECUTOR_DECLARE_MAKE_OWNER_FRIENDSHIP", "a00195.html#gae126fda1116bfe9f8b635898ba70c3f1", null ],
    [ "BifrostGraph::Executor::DeleterFunc", "a00195.html#ga59efee36706786e4d8d17d00f799b85c", null ],
    [ "BifrostGraph::Executor::makeOwner", "a00195.html#ga548c6dd0e8b5c4e6e751eb2668f8ef3a", null ],
    [ "BifrostGraph::Executor::makeOwner", "a00195.html#ga5a2c0db91175c1b59771625571e8bdfd", null ]
];