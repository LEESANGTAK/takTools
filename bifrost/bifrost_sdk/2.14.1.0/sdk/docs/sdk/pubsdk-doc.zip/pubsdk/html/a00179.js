var a00179 =
[
    [ "Bifrost::Geometry::clearGeometryPrototypes", "a00179.html#ga5471d5eb4c3c473f9c8faa5c2e1345df", null ],
    [ "Bifrost::Geometry::debugDump", "a00179.html#ga5bd1af6e35987fd44162354374e7e7f1", null ]
];