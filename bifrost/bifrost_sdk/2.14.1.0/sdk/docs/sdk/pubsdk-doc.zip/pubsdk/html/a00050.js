var a00050 =
[
    [ "Amino::NoStopState_t", "a00334.html", "a00334" ],
    [ "Amino::StopToken", "a00338.html", "a00338" ],
    [ "Amino::StopSource", "a00342.html", "a00342" ],
    [ "Amino::StopCallback< Callback >", "a00346.html", "a00346" ],
    [ "AMINO_API", "a00050.html#a54824452a1d4aaf86f1f345a0eec0a4c", null ],
    [ "StopCallback", "a00050.html#abc2cfda3c4970739f131371ddd2e458a", null ],
    [ "StopCallback", "a00050.html#a5a4193e7aefe02aa4e284a05b4adbb1b", null ]
];