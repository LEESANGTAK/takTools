var a00242 =
[
    [ "PluginHostData", "a00242.html#a899188bd9c1180e9f6fc435f6c13856a", null ],
    [ "~PluginHostData", "a00242.html#a65531fa15ff13b3ca55971b9c86aa1d0", null ],
    [ "m_object", "a00242.html#a96cadecb38b244ba7840a554df3d1568", null ]
];