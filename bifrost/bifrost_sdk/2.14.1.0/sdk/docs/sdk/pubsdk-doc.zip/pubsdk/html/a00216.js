var a00216 =
[
    [ "GeoLocation", "a00938.html", "a00938" ],
    [ "Adaptivity", "a00216.html#a89752ebd22677117bbc839ef4dd4e8d1", [
      [ "Automatic", "a00216.html#a89752ebd22677117bbc839ef4dd4e8d1a086247a9b57fde6eefee2a0c4752242d", null ],
      [ "VariedFromProperty", "a00216.html#a89752ebd22677117bbc839ef4dd4e8d1a123d5187e2e8c4f9909f6ca9987db994", null ],
      [ "Off", "a00216.html#a89752ebd22677117bbc839ef4dd4e8d1ad15305d7a4e34e02489c74a5ef542f36", null ]
    ] ],
    [ "DataInterpolationMode", "a00216.html#a9890fc0c44f2a1727d0255bf263627af", [
      [ "Nearest", "a00216.html#a9890fc0c44f2a1727d0255bf263627afa60494f02d440f316319dd0fad40ad007", null ],
      [ "Linear", "a00216.html#a9890fc0c44f2a1727d0255bf263627afa32a843da6ea40ab3b17a3421ccdf671b", null ],
      [ "DefaultValue", "a00216.html#a9890fc0c44f2a1727d0255bf263627afa47650c07c124a01fcd3206d452ce6a1c", null ]
    ] ],
    [ "GeometryType", "a00216.html#af5b5b04957fc80330c88e9feae75ccca", [
      [ "not_a_geometry", "a00216.html#af5b5b04957fc80330c88e9feae75cccaacc396fc6ac11818c0adfe51cc6e48662", null ],
      [ "volume", "a00216.html#af5b5b04957fc80330c88e9feae75cccaa210ab9e731c9c36c2c38db15c28a8d1c", null ],
      [ "instances", "a00216.html#af5b5b04957fc80330c88e9feae75cccaa6fa9325472628103b7299e0e03a3cb93", null ],
      [ "mesh", "a00216.html#af5b5b04957fc80330c88e9feae75cccaa09bc81c3aa886b690f84c5aba4109e20", null ],
      [ "strands", "a00216.html#af5b5b04957fc80330c88e9feae75cccaad184598ceee8e1af7dbf43b53087d58b", null ],
      [ "points", "a00216.html#af5b5b04957fc80330c88e9feae75cccaa0aab81de5c4c87021772015efc184d67", null ]
    ] ]
];